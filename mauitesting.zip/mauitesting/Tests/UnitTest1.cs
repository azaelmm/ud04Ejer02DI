﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mauitesting.Tests;
using mauitesting;
using Xunit;
using mauitesting.Core;

namespace mauitesting.Tests
{
    public class UnitTest1
    {
        private readonly Operacions _operacions = new Operacions();

        [Theory]
        [InlineData(1, 2, 3)]
        [InlineData(-1, -1, -2)]
        public void Suma_ValidInputs_ReturnsExpected(double a, double b, double expected)
        {
            Assert.Equal(expected, _operacions.Suma(a, b));
        }

        [Theory]
        [InlineData(5, 3, 2)]
        [InlineData(-5, -3, -2)]
        public void Resta_ValidInputs_ReturnsExpected(double a, double b, double expected)
        {
            Assert.Equal(expected, _operacions.Resta(a, b));
        }

        [Theory]
        [InlineData(2, 3, 6)]
        [InlineData(-2, -3, 6)]
        public void Multiplicacio_ValidInputs_ReturnsExpected(double a, double b, double expected)
        {
            Assert.Equal(expected, _operacions.Multiplicacio(a, b));
        }

        [Theory]
        [InlineData(6, 2, 3)]
        [InlineData(-6, -2, 3)]
        public void Divisio_ValidInputs_ReturnsExpected(double a, double b, double expected)
        {
            Assert.Equal(expected, _operacions.Divisio(a, b));
        }

        [Fact]
        public void Divisio_DivideByZero_ThrowsException()
        {
            Assert.Throws<DivideByZeroException>(() => _operacions.Divisio(5, 0));
        }
    }
}


