﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using mauitesting.Core;


namespace Calculadora.ViewModel
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly Operacions _operacions = new Operacions();

        private double _primerValor;
        private double _segonValor;
        private string _resultat;

        public double PrimerValor
        {
            get => _primerValor;
            set
            {
                _primerValor = value;
                OnPropertyChanged();
            }
        }

        public double SegonValor
        {
            get => _segonValor;
            set
            {
                _segonValor = value;
                OnPropertyChanged();
            }
        }

        public string Resultat
        {
            get => _resultat;
            set
            {
                _resultat = value;
                OnPropertyChanged();
            }
        }

        public ICommand SumaCommand => new Command(() => Calcula(() => _operacions.Suma(PrimerValor, SegonValor)));
        public ICommand RestaCommand => new Command(() => Calcula(() => _operacions.Resta(PrimerValor, SegonValor)));
        public ICommand MultiplicacioCommand => new Command(() => Calcula(() => _operacions.Multiplicacio(PrimerValor, SegonValor)));
        public ICommand DivisioCommand => new Command(() => Calcula(() => _operacions.Divisio(PrimerValor, SegonValor)));

        private void Calcula(Func<double> operacio)
        {
            try
            {
                Resultat = operacio().ToString();
            }
            catch (DivideByZeroException ex)
            {
                Resultat = ex.Message;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

