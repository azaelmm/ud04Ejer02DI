﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mauitesting.Core
{
    public class Operacions
    {
        public double Suma(double a, double b) => a + b;

        public double Resta(double a, double b) => a - b;

        public double Multiplicacio(double a, double b) => a * b;

        public double Divisio(double a, double b)
        {
            if (b == 0)
            {
                throw new DivideByZeroException("No es pot dividir entre zero.");
            }
            return a / b;
        }
    }
}

